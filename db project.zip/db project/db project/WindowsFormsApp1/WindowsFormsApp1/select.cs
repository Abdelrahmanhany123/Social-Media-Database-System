﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    internal class select : Form
    {
        private Label labelTitle;
        private Label labelTable;
        private Label labelColumns;
        private Label labelWhere;

        private ComboBox comboBoxTables;
        private CheckedListBox checkedListBox1;
        private TextBox textBox1;
        private Button buttonSelect;
        private DataGridView dataGridView2;

        string connectionString =
            @"Data Source=.;Initial Catalog=SocialMediaDB;Integrated Security=True";

        public select()
        {
            InitializeComponent();
            LoadTables();
        }

        private void InitializeComponent()
        {
            this.labelTitle = new Label();
            this.labelTable = new Label();
            this.labelColumns = new Label();
            this.labelWhere = new Label();

            this.comboBoxTables = new ComboBox();
            this.checkedListBox1 = new CheckedListBox();
            this.textBox1 = new TextBox();
            this.buttonSelect = new Button();
            this.dataGridView2 = new DataGridView();

            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // TITLE

            labelTitle.AutoSize = true;
            labelTitle.Font = new Font("Modern No. 20", 16F, FontStyle.Bold);
            labelTitle.Location = new Point(250, 20);
            labelTitle.Text = "SELECT OPERATION";

            // TABLE LABEL
 
            labelTable.AutoSize = true;
            labelTable.Font = new Font("Modern No. 20", 12F, FontStyle.Bold);
            labelTable.Location = new Point(30, 70);
            labelTable.Text = "Select Table";

            // COMBOBOX

            comboBoxTables.Location = new Point(30, 100);
            comboBoxTables.Size = new System.Drawing.Size(280, 24);
            comboBoxTables.SelectedIndexChanged += new EventHandler(comboBoxTables_SelectedIndexChanged);

            // COLUMNS LABEL

            labelColumns.AutoSize = true;
            labelColumns.Font = new Font("Modern No. 20", 12F, FontStyle.Bold);
            labelColumns.Location = new Point(30, 145);
            labelColumns.Text = "Select Columns";


            // CHECKED LIST BOX

            checkedListBox1.BackColor = System.Drawing.SystemColors.ControlLight;
            checkedListBox1.Font = new Font("Modern No. 20", 10F, FontStyle.Bold);
            checkedListBox1.ForeColor = System.Drawing.SystemColors.WindowFrame;
            checkedListBox1.FormattingEnabled = true;
            checkedListBox1.Location = new Point(30, 175);
            checkedListBox1.Size = new System.Drawing.Size(280, 200);

            // WHERE LABEL

            labelWhere.AutoSize = true;
            labelWhere.Font = new Font("Modern No. 20", 12F, FontStyle.Bold);
            labelWhere.Location = new Point(30, 395);
            labelWhere.Text = "Where (optional)";

            // WHERE TEXTBOX
     
            textBox1.Location = new Point(30, 425);
            textBox1.Size = new System.Drawing.Size(280, 22);

            // SELECT BUTTON
 
            buttonSelect.Text = "SELECT";
            buttonSelect.Font = new Font("Modern No. 20", 12F, FontStyle.Bold);
            buttonSelect.Size = new System.Drawing.Size(140, 50);
            buttonSelect.Location = new Point(85, 470);
            buttonSelect.Click += new EventHandler(buttonSelect_Click);

            // DATA GRID VIEW

            dataGridView2.Location = new Point(345, 70);
            dataGridView2.Size = new System.Drawing.Size(620, 450);
            dataGridView2.ColumnHeadersHeightSizeMode =
                DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.RowTemplate.Height = 24;
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView2.ReadOnly = true;

            // FORM

            this.ClientSize = new System.Drawing.Size(1000, 560);
            this.Controls.Add(labelTitle);
            this.Controls.Add(labelTable);
            this.Controls.Add(comboBoxTables);
            this.Controls.Add(labelColumns);
            this.Controls.Add(checkedListBox1);
            this.Controls.Add(labelWhere);
            this.Controls.Add(textBox1);
            this.Controls.Add(buttonSelect);
            this.Controls.Add(dataGridView2);

            this.Name = "select";
            this.Text = "Select Operation";

            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        // LOAD TABLES

        private void LoadTables()
        {
            comboBoxTables.Items.Add("USERS");
            comboBoxTables.Items.Add("POSTS");
            comboBoxTables.Items.Add("PHOTOS");
            comboBoxTables.Items.Add("VIDEOS");
            comboBoxTables.Items.Add("COMMENTS");
            comboBoxTables.Items.Add("HASHTAG");
            comboBoxTables.Items.Add("LOGIN");
            comboBoxTables.Items.Add("FOLLOWERS");
            comboBoxTables.Items.Add("POST_LIKE");
            comboBoxTables.Items.Add("COMMENT_LIKE");
            comboBoxTables.Items.Add("POST_TAG");
   
        }

        // TABLE FIELDS MAP
  
        private string[] GetFieldsForTable(string tableName)
        {
            switch (tableName)
            {
                case "USERS":
                    return new[] { "user_id", "username", "email", "bio", "created_at", "photo_url" };
                case "POSTS":
                    return new[] { "post_id", "user_id", "caption", "created_at" };
                case "PHOTOS":
                    return new[] { "photo_id", "post_id", "photo_url" };
                case "VIDEOS":
                    return new[] { "video_id", "post_id", "video_url" };
                case "COMMENTS":
                    return new[] { "comment_id", "post_id", "user_id", "comment_text", "created_at" };
                case "HASHTAG":
                    return new[] { "hashtag_id", "hashtag_name" };
                case "LOGIN":
                    return new[] { "login_id", "login_ip", "login_time", "user_id" };
                case "FOLLOWERS":
                    return new[] { "follower_id", "followee_id" };
                case "POST_LIKE":
                    return new[] { "post_id", "user_id", "like_count" };
                case "COMMENT_LIKE":
                    return new[] { "comment_id", "user_id", "like_count" };
          
                case "POST_TAG":
                    return new[] { "post_id", "hashtag_id" };
                case "USER_HASHTAGS":
                    return new[] { "user_id", "hashtag_id" };
                default:
                    return new string[0];
            }
        }


        // ON TABLE SELECTED — rebuild column checkboxes

        private void comboBoxTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            checkedListBox1.Items.Clear();
            dataGridView2.DataSource = null;
            textBox1.Clear();

            if (comboBoxTables.SelectedItem == null) return;

            string tableName = comboBoxTables.SelectedItem.ToString();
            string[] fields = GetFieldsForTable(tableName);

            foreach (string field in fields)
                checkedListBox1.Items.Add(field, true); // checked by default
        }

        // SELECT BUTTON CLICK

        private void buttonSelect_Click(object sender, EventArgs e)
        {
            if (comboBoxTables.SelectedItem == null)
            {
                MessageBox.Show("Please select a table.");
                return;
            }

            if (checkedListBox1.CheckedItems.Count == 0)
            {
                MessageBox.Show("Please select at least one column.");
                return;
            }

            string tableName = comboBoxTables.SelectedItem.ToString();

            // Build column list from checked items
            string[] selectedColumns = new string[checkedListBox1.CheckedItems.Count];
            for (int i = 0; i < checkedListBox1.CheckedItems.Count; i++)
                selectedColumns[i] = checkedListBox1.CheckedItems[i].ToString();

            string columnList = string.Join(", ", selectedColumns);

            // Build query
            string query = $"SELECT {columnList} FROM {tableName}";

            string condition = textBox1.Text.Trim();
            if (!string.IsNullOrEmpty(condition))
                query += $" WHERE {condition}";

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);

                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dataGridView2.DataSource = dt;

                    if (dt.Rows.Count == 0)
                        MessageBox.Show("No records found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}