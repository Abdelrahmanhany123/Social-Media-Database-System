﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    internal class Delete : Form
    {
        private Label label1;
        private Label label2;
        private Label label3;

        private ComboBox comboBoxTables;
        private TextBox textBoxCondition;
        private Button button1;


        string connectionString =
            @"Data Source=.;Initial Catalog=SocialMediaDB;Integrated Security=True";

        public Delete()
        {
            InitializeComponent();
            LoadTables();
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();

            this.comboBoxTables = new ComboBox();
            this.textBoxCondition = new TextBox();
            this.button1 = new Button();

            this.SuspendLayout();

       
            // TITLE

            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font(
                "Modern No. 20",
                16F,
                System.Drawing.FontStyle.Bold);

            label1.Location = new System.Drawing.Point(120, 30);
            label1.Text = "DELETE OPERATION";

       
            // TABLE LABEL
           
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font(
                "Modern No. 20",
                12F,
                System.Drawing.FontStyle.Bold);

            label2.Location = new System.Drawing.Point(40, 100);
            label2.Text = "Select Table";

           
            // COMBOBOX
     
            comboBoxTables.Location = new System.Drawing.Point(45, 135);
            comboBoxTables.Size = new System.Drawing.Size(320, 24);

           
            // CONDITION LABEL
         
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font(
                "Modern No. 20",
                12F,
                System.Drawing.FontStyle.Bold);

            label3.Location = new System.Drawing.Point(40, 190);
            label3.Text = "Condition";

            // CONDITION TEXTBOX
        
            textBoxCondition.Location = new System.Drawing.Point(45, 225);
            textBoxCondition.Size = new System.Drawing.Size(420, 22);

            // DELETE BUTTON
         
            button1.Text = "DELETE";
            button1.Font = new System.Drawing.Font(
                "Modern No. 20",
                12F,
                System.Drawing.FontStyle.Bold);

            button1.Size = new System.Drawing.Size(140, 50);
            button1.Location = new System.Drawing.Point(180, 310);

            button1.Click += new EventHandler(button1_Click);

            // FORM

            this.ClientSize = new System.Drawing.Size(550, 420);

            this.Controls.Add(label1);
            this.Controls.Add(label2);
            this.Controls.Add(comboBoxTables);
            this.Controls.Add(label3);
            this.Controls.Add(textBoxCondition);
            this.Controls.Add(button1);

            this.Name = "Delete";

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        // LOAD TABLES

        private void LoadTables()
        {
            comboBoxTables.Items.Add("USERS");
            comboBoxTables.Items.Add("POSTS");
            comboBoxTables.Items.Add("PHOTOS");
            comboBoxTables.Items.Add("VIDEOS");
            comboBoxTables.Items.Add("COMMENTS");
            comboBoxTables.Items.Add("HASHTAG");
            comboBoxTables.Items.Add("LOGIN");
            comboBoxTables.Items.Add("FOLLOWER");
            comboBoxTables.Items.Add("POST_LIKE");
            comboBoxTables.Items.Add("COMMENT_LIKE");
            comboBoxTables.Items.Add("POST_TAG");
            comboBoxTables.Items.Add("USER_HASHTAG");
        }

  
        // DELETE BUTTON
 
        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBoxTables.SelectedItem == null)
            {
                MessageBox.Show("Please select a table.");
                return;
            }

            if (textBoxCondition.Text.Trim() == "")
            {
                MessageBox.Show("Please enter a condition.");
                return;
            }

            string tableName = comboBoxTables.SelectedItem.ToString();
            string condition = textBoxCondition.Text;

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                  
                    // USERS CASCADE DELETE
                  
                    if (tableName == "USERS")
                    {
                        string getUserIdQuery = $"SELECT user_id FROM USERS WHERE {condition}";
                        SqlCommand getUserCmd = new SqlCommand(getUserIdQuery, con);

                        object result = getUserCmd.ExecuteScalar();

                        if (result == null)
                        {
                            MessageBox.Show("User not found.");
                            return;
                        }

                        int userId = Convert.ToInt32(result);

                        // LOGIN
                        new SqlCommand(
                            $"DELETE FROM LOGIN WHERE user_id = {userId}", con).ExecuteNonQuery();

                        // FOLLOWERS (FIXED: follower_id + following_id)
                        new SqlCommand(
                            $"DELETE FROM FOLLOWERS WHERE follower_id = {userId} OR followee_id = {userId}",
                            con).ExecuteNonQuery();

                        // POST_LIKE
                        new SqlCommand(
                            $"DELETE FROM POST_LIKE WHERE user_id = {userId}", con).ExecuteNonQuery();

                        // COMMENT_LIKE
                        new SqlCommand(
                            $"DELETE FROM COMMENT_LIKE WHERE user_id = {userId}", con).ExecuteNonQuery();

                        // COMMENTS made by user
                        new SqlCommand(
                            $"DELETE FROM COMMENTS WHERE user_id = {userId}", con).ExecuteNonQuery();

                        // POSTS-related cleanup
                        new SqlCommand(
                            $"DELETE FROM PHOTOS WHERE post_id IN (SELECT post_id FROM POSTS WHERE user_id = {userId})",
                            con).ExecuteNonQuery();

                        new SqlCommand(
                            $"DELETE FROM VIDEOS WHERE post_id IN (SELECT post_id FROM POSTS WHERE user_id = {userId})",
                            con).ExecuteNonQuery();

                        new SqlCommand(
                            $"DELETE FROM COMMENTS WHERE post_id IN (SELECT post_id FROM POSTS WHERE user_id = {userId})",
                            con).ExecuteNonQuery();

                        new SqlCommand(
                            $"DELETE FROM POST_TAG WHERE post_id IN (SELECT post_id FROM POSTS WHERE user_id = {userId})",
                            con).ExecuteNonQuery();

                        new SqlCommand(
                            $"DELETE FROM POST_LIKE WHERE post_id IN (SELECT post_id FROM POSTS WHERE user_id = {userId})",
                            con).ExecuteNonQuery();

                        new SqlCommand(
                            $"DELETE FROM POSTS WHERE user_id = {userId}",
                            con).ExecuteNonQuery();
                    }

      
                    // NORMAL DELETE (ALL TABLES)
               
                    string query = $"DELETE FROM {tableName} WHERE {condition}";
                    SqlCommand cmd = new SqlCommand(query, con);

                    int rows = cmd.ExecuteNonQuery();

                    MessageBox.Show(rows > 0 ? "Deletion successful!" : "No matching records found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}