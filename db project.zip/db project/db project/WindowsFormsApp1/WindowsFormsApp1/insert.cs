﻿using System;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    internal class insert : Form
    {
        private Label labelTitle;
        private Label labelTable;
        private Label labelFields;

        private ComboBox comboBoxTables;
        private Panel panelFields;
        private Button buttonInsert;

        string connectionString =
            @"Data Source=.;Initial Catalog=SocialMediaDB;Integrated Security=True";

        public insert()
        {
            InitializeComponent();
            LoadTables();
        }

        private void InitializeComponent()
        {
            this.labelTitle = new Label();
            this.labelTable = new Label();
            this.labelFields = new Label();

            this.comboBoxTables = new ComboBox();
            this.panelFields = new Panel();
            this.buttonInsert = new Button();

            this.SuspendLayout();

            // title 
            labelTitle.AutoSize = true;
            labelTitle.Font = new Font("Modern No. 20", 16F, FontStyle.Bold);
            labelTitle.Location = new System.Drawing.Point(120, 30);
            labelTitle.Text = "INSERT OPERATION";

          
            // Table label
      
            labelTable.AutoSize = true;
            labelTable.Font = new Font("Modern No. 20", 12F, FontStyle.Bold);
            labelTable.Location = new System.Drawing.Point(40, 100);
            labelTable.Text = "Select Table";

            // COMBOBOX
       
            comboBoxTables.Location = new System.Drawing.Point(45, 135);
            comboBoxTables.Size = new System.Drawing.Size(320, 24);
            comboBoxTables.SelectedIndexChanged += new EventHandler(comboBoxTables_SelectedIndexChanged);

       
            // FIELDS LABEL
       
            labelFields.AutoSize = true;
            labelFields.Font = new Font("Modern No. 20", 12F, FontStyle.Bold);
            labelFields.Location = new System.Drawing.Point(40, 185);
            labelFields.Text = "Fields";

            // FIELDS PANEL (dynamic textboxes go here)

            panelFields.Location = new System.Drawing.Point(40, 215);
            panelFields.Size = new System.Drawing.Size(560, 260);
            panelFields.AutoScroll = true;

    
            // INSERT BUTTON
   
            buttonInsert.Text = "INSERT";
            buttonInsert.Font = new Font("Modern No. 20", 12F, FontStyle.Bold);
            buttonInsert.Size = new System.Drawing.Size(140, 50);
            buttonInsert.Location = new System.Drawing.Point(195, 490);
            buttonInsert.Click += new EventHandler(buttonInsert_Click);

    
            // FORM
     
            this.ClientSize = new System.Drawing.Size(620, 570);
            this.Controls.Add(labelTitle);
            this.Controls.Add(labelTable);
            this.Controls.Add(comboBoxTables);
            this.Controls.Add(labelFields);
            this.Controls.Add(panelFields);
            this.Controls.Add(buttonInsert);

            this.Name = "insert";
            this.Text = "Insert Operation";

            this.ResumeLayout(false);
            this.PerformLayout();
        }

        // LOAD TABLES

        private void LoadTables()
        {
            comboBoxTables.Items.Add("USERS");
            comboBoxTables.Items.Add("POSTS");
            comboBoxTables.Items.Add("PHOTOS");
            comboBoxTables.Items.Add("VIDEOS");
            comboBoxTables.Items.Add("COMMENTS");
            comboBoxTables.Items.Add("HASHTAG");
            comboBoxTables.Items.Add("LOGIN");
            comboBoxTables.Items.Add("FOLLOWERS");
            comboBoxTables.Items.Add("POST_LIKE");
            comboBoxTables.Items.Add("COMMENT_LIKE");
       
            comboBoxTables.Items.Add("POST_TAG");

        }

        // TABLE FIELDS MAP
        // Returns the column names for each table

        private string[] GetFieldsForTable(string tableName)
        {
            switch (tableName)
            {
                case "USERS":
                    return new[] { "username", "email", "bio", "created_at", "photo_url" };
                case "POSTS":
                    return new[] { "user_id", "caption", "created_at" ,"location"};          
                case "PHOTOS":
                    return new[] { "photo_url", "post_id","size", "created_at" };                      
                case "VIDEOS":
                    return new[] { "post_id", "video_url" ,"size","created_at"};                       
                case "COMMENTS":
                    return new[] { "post_id", "user_id", "comment_text", "created_at" }; 
                case "HASHTAG":
                    return new[] { "hashtag_name","created_at" };                              
                case "LOGIN":
                    return new[] {  "user_id", "login_ip" ,"login_time"};            
                case "POST_LIKE":
                    return new[] { "post_id", "user_id", "like_count" };          
                case "COMMENT_LIKES":
                    return new[] { "comment_id", "user_id", "like_count" };
                case "FOLLOWERS":
                    return new[] { "followee_id" };
                case "POST_TAG":
                    return new[] { "post_id", "hashtag_id" };
           
                default:
                    return new string[0];
            }
        }

        // ON TABLE SELECTED — rebuild the fields panel

        private void comboBoxTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            panelFields.Controls.Clear();

            if (comboBoxTables.SelectedItem == null) return;

            string tableName = comboBoxTables.SelectedItem.ToString();
            string[] fields = GetFieldsForTable(tableName);

            int y = 5;
            foreach (string field in fields)
            {
                // Label
                Label lbl = new Label();
                lbl.Text = field;
                lbl.Font = new Font("Modern No. 20", 10F, FontStyle.Bold);
                lbl.AutoSize = true;
                lbl.Location = new System.Drawing.Point(0, y);
                panelFields.Controls.Add(lbl);

                // TextBox
                TextBox txt = new TextBox();
                txt.Name = "txt_" + field;
                txt.Location = new System.Drawing.Point(160, y);
                txt.Size = new System.Drawing.Size(360, 22);
                panelFields.Controls.Add(txt);

                y += 40;
            }
        }

        // INSERT BUTTON CLICK
    
        private void buttonInsert_Click(object sender, EventArgs e)
        {
            if (comboBoxTables.SelectedItem == null)
            {
                MessageBox.Show("Please select a table.");
                return;
            }

            string tableName = comboBoxTables.SelectedItem.ToString();
            string[] fields = GetFieldsForTable(tableName);

            if (fields.Length == 0)
            {
                MessageBox.Show("No fields defined for this table.");
                return;
            }

            // Collect values from the dynamic textboxes
            string[] values = new string[fields.Length];
            for (int i = 0; i < fields.Length; i++)
            {
                Control[] ctrls = panelFields.Controls.Find("txt_" + fields[i], false);
                if (ctrls.Length == 0 || string.IsNullOrWhiteSpace(ctrls[0].Text))
                {
                    MessageBox.Show($"Please fill in the field: {fields[i]}");
                    return;
                }
                values[i] = ctrls[0].Text.Trim();
            }

            // Build the INSERT query using parameters
            string columnList = string.Join(", ", fields);
            string paramList = string.Join(", ", Array.ConvertAll(fields, f => "@" + f));
            string query = $"INSERT INTO {tableName} ({columnList}) VALUES ({paramList})";

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query, con);

                    for (int i = 0; i < fields.Length; i++)
                        cmd.Parameters.AddWithValue("@" + fields[i], values[i]);

                    int rows = cmd.ExecuteNonQuery();
                    MessageBox.Show(rows > 0 ? "Insertion successful!" : "Insertion failed.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}