﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    internal class update : Form
    {
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;

        private ComboBox comboBoxTables;
        private ComboBox comboBoxColumns;
        private TextBox textBoxNewValue;
        private TextBox textBoxCondition;
        private Button buttonUpdate;

        string connectionString =
            @"Data Source=.;Initial Catalog=SocialMediaDB;Integrated Security=True";

        public update()
        {
            InitializeComponent();
            LoadTables();
        }

        private void InitializeComponent()
        {
            this.label1 = new Label();
            this.label2 = new Label();
            this.label3 = new Label();
            this.label4 = new Label();

            this.comboBoxTables = new ComboBox();
            this.comboBoxColumns = new ComboBox();
            this.textBoxNewValue = new TextBox();
            this.textBoxCondition = new TextBox();
            this.buttonUpdate = new Button();

            this.SuspendLayout();

            // TITLE 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("Modern No. 20", 16F, System.Drawing.FontStyle.Bold);
            label1.Location = new System.Drawing.Point(160, 20);
            label1.Text = "UPDATE OPERATION";

            // TABLE
            label2.AutoSize = true;
            label2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold);
            label2.Location = new System.Drawing.Point(40, 80);
            label2.Text = "Select Table";

            comboBoxTables.Location = new System.Drawing.Point(45, 110);
            comboBoxTables.Size = new System.Drawing.Size(350, 24);
            comboBoxTables.SelectedIndexChanged += ComboBoxTables_SelectedIndexChanged;

            // COLUMN
            label3.AutoSize = true;
            label3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold);
            label3.Location = new System.Drawing.Point(40, 150);
            label3.Text = "Select Column";

            comboBoxColumns.Location = new System.Drawing.Point(45, 180);
            comboBoxColumns.Size = new System.Drawing.Size(350, 24);

            // NEW VALUE
            label4.AutoSize = true;
            label4.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold);
            label4.Location = new System.Drawing.Point(40, 220);
            label4.Text = "New Value";

            textBoxNewValue.Location = new System.Drawing.Point(45, 250);
            textBoxNewValue.Size = new System.Drawing.Size(350, 22);

            // CONDITION 
            Label label5 = new Label();
            label5.AutoSize = true;
            label5.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold);
            label5.Location = new System.Drawing.Point(40, 290);
            label5.Text = "Condition (WHERE)";

            textBoxCondition.Location = new System.Drawing.Point(45, 320);
            textBoxCondition.Size = new System.Drawing.Size(350, 22);

            // BUTTON
            buttonUpdate.Text = "UPDATE";
            buttonUpdate.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold);
            buttonUpdate.Size = new System.Drawing.Size(140, 50);
            buttonUpdate.Location = new System.Drawing.Point(160, 370);
            buttonUpdate.Click += ButtonUpdate_Click;

            //  FORM 
            this.ClientSize = new System.Drawing.Size(460, 450);
            this.Controls.Add(label1);
            this.Controls.Add(label2);
            this.Controls.Add(comboBoxTables);
            this.Controls.Add(label3);
            this.Controls.Add(comboBoxColumns);
            this.Controls.Add(label4);
            this.Controls.Add(textBoxNewValue);
            this.Controls.Add(label5);
            this.Controls.Add(textBoxCondition);
            this.Controls.Add(buttonUpdate);

            this.Name = "UpdateForm";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        //  TABLES
        private void LoadTables()
        {
            comboBoxTables.Items.Add("USERS");
            comboBoxTables.Items.Add("POSTS");
            comboBoxTables.Items.Add("PHOTOS");
            comboBoxTables.Items.Add("VIDEOS");
            comboBoxTables.Items.Add("COMMENTS");
            comboBoxTables.Items.Add("HASHTAG");
            comboBoxTables.Items.Add("LOGIN");
            comboBoxTables.Items.Add("FOLLOWERS");
            comboBoxTables.Items.Add("POST_LIKE");
            comboBoxTables.Items.Add("COMMENT_LIKE");
        }

        // COLUMNS PER TABLE 
        private void ComboBoxTables_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBoxColumns.Items.Clear();

            switch (comboBoxTables.SelectedItem.ToString())
            {
                case "USERS":
                    comboBoxColumns.Items.AddRange(new string[]
                    { "username", "email", "password" });
                    break;

                case "POSTS":
                    comboBoxColumns.Items.AddRange(new string[]
                    { "content", "caption" });
                    break;

                case "COMMENTS":
                    comboBoxColumns.Items.Add("comment_text");
                    break;

                case "FOLLOWERS":
                    comboBoxColumns.Items.AddRange(new string[]
                    { "follower_id", "followee_id" });
                    break;

                case "POSTS_LIKE":
                case "COMMENT_LIKE":
                    comboBoxColumns.Items.Add("like_type");
                    break;

                default:
                    comboBoxColumns.Items.Add("id");
                    break;
            }
        }

        //UPDATE BUTTON
        private void ButtonUpdate_Click(object sender, EventArgs e)
        {
            if (comboBoxTables.SelectedItem == null ||
                comboBoxColumns.SelectedItem == null)
            {
                MessageBox.Show("Select table and column.");
                return;
            }

            if (textBoxNewValue.Text.Trim() == "" ||
                textBoxCondition.Text.Trim() == "")
            {
                MessageBox.Show("Enter value and condition.");
                return;
            }

            string table = comboBoxTables.SelectedItem.ToString();
            string column = comboBoxColumns.SelectedItem.ToString();
            string newValue = textBoxNewValue.Text;
            string condition = textBoxCondition.Text;

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    string query =
                        $"UPDATE {table} SET {column} = @value WHERE {condition}";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@value", newValue);

                    int rows = cmd.ExecuteNonQuery();

                    MessageBox.Show(rows > 0
                        ? "Update successful!"
                        : "No matching records found.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}